const story=[
["记录员","哥特历 014.M42。\n边陲世界「维勒斯九号」失去了最后一座星港。\n通讯中断前，只留下了一句重复播放的祷词：\n“黑暗之中，只有帝皇注视着我们。”"],
["审判官 卡西安·沃尔","你叫伊莱娅？很好。别把这里当成战场。\n这里是证据现场。战场上允许犯错，审判庭不允许。"],
["伊莱娅","我是帝国卫队第十九远征团的通讯兵。我的小队在着陆后失联。"]
];
const nodes={
start:{s:"审判官 卡西安·沃尔",t:"舰桥外是一片没有灯光的城市。高塔像被烧焦的祷告书。\n我需要知道：你最后一次收到小队讯息时，听见了什么？",c:[
["“求救。有人在门外。”","a",{suspicion:5,humanity:2}],
["“一切正常。”","b",{faith:5,suspicion:2}],
["我只记得枪声。","c",{humanity:5,suspicion:-2}]]},
a:{s:"审判官 卡西安·沃尔",t:"求救？很好。恐惧不会撒谎，但人会。\n我们进去。",n:"city"},
b:{s:"审判官 卡西安·沃尔",t:"一切正常……在这种地方，这句话反而最不正常。\n我们进去。",n:"city"},
c:{s:"审判官 卡西安·沃尔",t:"枪声意味着有人还活着。至少当时是。\n我们进去。",n:"city"},
city:{s:"系统",t:"你们穿过废弃的祈祷广场。地面上摆满了蜡烛，却没有一个人点燃它们。\n忽然，通讯器亮了。一个熟悉的声音从噪声中传来。",n:"voice"},
voice:{s:"未知声音",t:"伊莱娅……如果你能听见……不要相信审判官。\n他不是来救我们的。",c:[
["拔枪，对准审判官。","gun",{suspicion:12,humanity:-8}],
["保持沉默，继续听。","listen",{suspicion:-3,faith:2}],
["告诉审判官有人在冒充我的小队。","report",{faith:5,suspicion:-5}]]},
gun:{s:"审判官 卡西安·沃尔",t:"很好。至少你有胆量。\n但如果你认为我有问题，就先问一个问题：为什么你的通讯器，会收到来自三天前已经死亡的小队长的声音？",n:"reveal"},
listen:{s:"未知声音",t:"你听见了自己的名字。随后，是你母亲年轻时唱过的一首歌。\n你从未告诉过任何人这件事。",n:"reveal"},
report:{s:"审判官 卡西安·沃尔",t:"你做得对。不要相信任何未经验证的声音。\n他示意舰队切断所有无线频道。",n:"reveal"},
reveal:{s:"系统",t:"城市深处传来低沉的钟声。\n一座地下圣所的门正在开启。\n门后没有恶魔，也没有军队。\n只有成千上万名失踪者留下的身份证牌。\n而最上面的一块，写着你的名字。",c:[
["进入圣所。","e1",{faith:4,humanity:4}],
["烧毁身份证牌。","e2",{humanity:-10,suspicion:5}],
["要求审判官先解释。","e3",{suspicion:8,faith:-3}]]},
e1:{s:"结局：灰烬中的祷告",t:"你走进黑暗。\n你不知道等待你的究竟是异形、叛徒，还是某种更古老的东西。\n但你知道一件事：你已经选择了继续前进。\n\n“帝皇注视着我们。”",end:true},
e2:{s:"结局：拒绝",t:"火焰吞没了身份证牌。\n审判官没有阻止你。\n“有时候，活下来的人必须学会烧掉死者留下的问题。”",end:true},
e3:{s:"结局：审判",t:"审判官沉默了很久。\n“解释？如果我能解释，就不会需要审判庭。”\n他把一把旧式爆弹枪递给你。\n“现在，轮到你判断了。”",end:true}
};
let si=0,key=null,st={faith:50,suspicion:0,humanity:50};
const S=document.querySelector("#speaker"),T=document.querySelector("#text"),C=document.querySelector("#choices"),N=document.querySelector("#next");
function stats(d={}){for(let k in d)st[k]=Math.max(0,Math.min(100,st[k]+d[k]));document.querySelector("#faith").textContent="信仰 "+st.faith;document.querySelector("#suspicion").textContent="怀疑 "+st.suspicion;document.querySelector("#humanity").textContent="人性 "+st.humanity}
function render(o){
 S.textContent=o.s||o[0];T.textContent=o.t||o[1];C.innerHTML="";
 if(o.c){N.style.display="none";o.c.forEach(x=>{let b=document.createElement("button");b.className="choice";b.textContent=x[0];b.onclick=()=>{stats(x[2]);show(x[1])};C.appendChild(b)})}
 else if(o.end){N.style.display="none";let b=document.createElement("button");b.className="choice";b.textContent="重新开始";b.onclick=restart;C.appendChild(b)}
 else N.style.display="block";
}
function show(k){key=k;render(nodes[k])}
N.onclick=()=>{if(si<story.length)render(story[si++]);else show("start")}
function restart(){si=0;key=null;st={faith:50,suspicion:0,humanity:50};stats();render(story[si++])}
document.querySelector("#save").onclick=()=>{localStorage.vn40k=JSON.stringify({si,key,st});document.querySelector("#save").textContent="已保存";setTimeout(()=>document.querySelector("#save").textContent="保存",900)}
try{let q=JSON.parse(localStorage.vn40k);if(q){si=q.si;key=q.key;st=q.st;stats();key?show(key):render(story[Math.min(si++,story.length-1)])}else restart()}catch(e){restart()}
